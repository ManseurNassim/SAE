Tests : 




def test_create_network():
    # Test avec un fichier valide
    assert create_network("newfiles/FichierTest.csv") == {'Barbra': ['Cloe', 'Vittorio', 'Marwa'], 'Cloe': ['Barbra', 'Glenys', 'Louis'], 'Louis': ['Rufino', 'Cloe'], 'Rufino': ['Louis', 'Mady'], 'Idelle': ['Mady'], 'Mady': ['Idelle', 'Rufino'], 'Björn': ['Giedrius', 'Faizel'], 'Giedrius': ['Björn'], 'Glenys': ['Cloe'], 'Vittorio': ['Barbra'], 'Marwa': ['Barbra'], 'Faizel': ['Björn']}
    # Test avec un fichier vide
    assert create_network("newfiles/FichierVide.csv") == {}
    # Test avec un fichier qui n'existe pas
    try:
        create_network("newfiles/FichierInexistant.csv")
    except FileNotFoundError:
        assert True
    else:
        assert False
    print("Les tests de la fonction create_network sont passés !")


def test_is_a_community():
    # On crée un réseau de test
    reseau = {'Alice': ['Bob', 'Charlie', 'Dominique'],
              'Bob': ['Alice', 'Charlie', 'Dominique'],
              'Charlie': ['Alice'],
              'Dominique': ['Alice', 'Bob']}

    # On teste si le groupe ["Alice","Bob","Dominique"] est une communauté
    assert is_a_community(reseau, ["Alice","Bob","Dominique"]) == True

    # On teste si le groupe ["Alice","Bob","Charlie"] n'est pas une communauté
    assert is_a_community(reseau, ["Alice","Bob","Charlie"]) == False

    # On teste si le groupe ["Bob","Dominique"] n'est pas une communauté
    assert is_a_community(reseau, ["Bob","Dominique"]) == False

    # On teste si le groupe ["Alice","Bob","Dominique","Charlie"] n'est pas une communauté
    assert is_a_community(reseau, ["Alice","Bob","Dominique","Charlie"]) == False
    print("Les tests ont été passés avec succès")


def test_all_his_friends():
    reseau = {'Alice': ['Bob', 'Charlie', 'Dominique'], 'Bob': ['Alice', 'Charlie', 'Dominique'], 'Charlie': ['Alice', 'Bob'], 'Dominique': ['Alice', 'Bob']}
    # Test avec un groupe d'amis qui sont tous amis avec la personne
    assert all_his_friends(reseau, 'Alice', ['Bob', 'Charlie', 'Dominique']) == True
    # Test avec un groupe d'amis qui ne sont pas tous amis avec la personne
    assert all_his_friends(reseau, 'Charlie', ['Bob', 'Dominique']) == False
    # Test avec un groupe vide
    assert all_his_friends(reseau, 'Charlie', []) == True
    print("Les tests de la fonction all_his_friends sont passés!")


def test_are_friends():
    # Test de base : Alice et Bob sont amis
    assert are_friends(reseau, 'Alice', 'Bob') == True
    # Test de base : Alice et Charlie ne sont pas amis
    assert are_friends(reseau, 'Alice', 'Charlie') == False
    # Test de cas où l'un des deux noms de personnes n'existe pas dans le réseau
    assert are_friends(reseau, 'Alice', 'David') == False
    # Test de cas où les deux noms de personnes ne sont pas dans le réseau
    assert are_friends(reseau, 'David', 'Emilie') == False
    print("La fonction are_friends passe tous les tests.")

def test_get_people():
    # Test sur un réseau vide
    assert get_people({}) == []
    # Test sur un réseau non vide
    network = {'Alice': ['Bob', 'Charlie'], 'Bob': ['Alice', 'Charlie'], 'Charlie': ['Alice', 'Bob']}
    assert get_people(network) == ['Alice', 'Bob', 'Charlie']
    # Test sur un réseau où il y a des doublons de personnes
    network = {'Alice': ['Bob', 'Charlie'], 'Bob': ['Alice', 'Charlie'], 'Charlie': ['Alice', 'Bob'], 'Bob': ['Charlie']}
    assert get_people(network) == ['Alice', 'Bob', 'Charlie']
    print("Les tests ont été passés avec succès!")


def test_find_community_by_decreasing_popularity():
    # On crée un exemple de réseau
    network = create_network(
        [("Alice", "Bob"), ("Alice", "Charlie"), ("Bob", "Charlie"), ("Bob", "Dominique")]
    )
    # On teste si la fonction retourne la communauté maximale ["Bob", "Alice", "Dominique"]
    assert find_community_by_decreasing_popularity(network) == {"Bob", "Alice", "Dominique"}
    # On teste avec un autre exemple de réseau
    network = create_network([("Alice", "Bob"), ("Bob", "Charlie"), ("Charlie", "Dominique")])
    assert find_community_by_decreasing_popularity(network) == {"Bob", "Charlie"}
    print("Les tests de la fonction find_community_by_decreasing_popularity sont passés.")




def test_find_community_from_person():
    # On crée un réseau de test
    network = create_network(
        [("Alice", "Bob"), ("Bob", "Charlie"), ("Charlie", "Alice"), ("Bob", "Dominique"), ("Alice", "Dominique")]
    )
    # On teste pour la personne "Alice"
    community = find_community_from_person(network, "Alice")
    assert community == ["Alice", "Bob", "Dominique"], f"Erreur : {community}"
    # On teste pour la personne "Charlie"
    community = find_community_from_person(network, "Charlie")
    assert community == ["Charlie", "Bob"], f"Erreur : {community}"
    # On teste pour la personne "Bob"
    community = find_community_from_person(network, "Bob")
    assert community == ["Bob", "Alice", "Dominique"], f"Erreur : {community}"
    # On teste pour une personne qui n'est pas dans le réseau
    community = find_community_from_person(network, "Eve")
    assert community == [], f"Erreur : {community}"
    
    print("La fonction find_community_from_person passe tous les tests.")



def test_find_max_community():
    # On crée un réseau de test
    network = create_network(["Alice", "Bob", "Charlie", "Dominique"],
                             [("Alice", "Bob"),
                              ("Bob", "Charlie"),
                              ("Charlie", "Alice"),
                              ("Dominique", "Alice"),
                              ("Dominique", "Bob")])
    # On cherche la communauté maximale dans ce réseau
    max_community = find_max_community(network)
    # On vérifie que la communauté maximale trouvée est bien celle attendue
    expected_community = ["Alice", "Bob", "Dominique"]
    assert set(max_community) == set(expected_community), f"La communauté maximale trouvée {max_community} est différente de celle attendue {expected_community}"
    print("La fonction find_max_community passe les tests.")

def test_order_by_decreasing_popularity(network):
    # On crée un groupe de personnes pour effectuer le test
    group = ["Alice", "Bob", "Charlie"]
    # On utilise la fonction à tester
    result = order_by_decreasing_popularity(network, group)
    # On vérifie si le résultat est celui attendu
    expected_result = ["Bob", "Alice", "Charlie"]
    assert result == expected_result, f'Error: expected {expected_result}, got {result}'
    # On affiche un message de succès
    print("order_by_decreasing_popularity test passés !!.")


def test_find_community():
    # Test avec le reseau en exemple
    assert find_community(p_amis, ["Alice", "Bob", "Charlie", "Dominique"]) == ["Alice", "Bob", "Dominique"]
    assert find_community(p_amis, ["Charlie", "Alice", "Bob", "Dominique"]) == ["Charlie", "Bob"]
    assert find_community(p_amis, ["Charlie", "Alice", "Dominique"]) == ["Charlie"]
    
    # Test avec un reseau vide
    assert find_community({}, ["Alice", "Bob", "Charlie", "Dominique"]) == []
    
    # Test avec un groupe qui est déjà une communauté
    assert find_community(p_amis, ["Alice", "Bob", "Dominique"]) == ["Alice", "Bob", "Dominique"]
    
    print("Tous les test sont passés!")


