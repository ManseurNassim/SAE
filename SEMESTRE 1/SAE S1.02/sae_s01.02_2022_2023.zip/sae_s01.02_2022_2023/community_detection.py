##############
# SAE S01.01 #
##############

def liste_amis(amis, prenom):
    """
        Retourne la liste des amis de prenom en fonction du tableau amis.
    """
    prenoms_amis = []
    i = 0
    while i < len(amis)//2:
        if amis[2 * i] == prenom:
            prenoms_amis.append(amis[2*i+1])
        elif amis[2*i+1] == prenom:
            prenoms_amis.append(amis[2*i])
        i += 1
    return prenoms_amis

def nb_amis(amis, prenom):
    """ Retourne le nombre d'amis de prenom en fonction du tableau amis. """
    return len(liste_amis(amis, prenom))


def personnes_reseau(amis):
    """ Retourne un tableau contenant la liste des personnes du réseau."""
    people = []
    i = 0
    while i < len(amis):
        if amis[i] not in people:
            people.append(amis[i])
        i += 1
    return people

def taille_reseau(amis):
    """ Retourne le nombre de personnes du réseau."""
    return len(personnes_reseau(amis))

def lecture_reseau(path):
    """ Retourne le tableau d'amis en fonction des informations contenues dans le fichier path."""
    f = open(path, "r")
    l = f.readlines()
    f.close()
    amis = []
    i = 0
    while i < len(l):
        fr = l[i].split(";")
        amis.append(fr[0].strip())
        amis.append(fr[1].strip())
        i += 1
    return amis

def dico_reseau(amis):
    """ Retourne le dictionnaire correspondant au réseau."""
    dico = {}
    people = personnes_reseau(amis)
    i = 0
    while i < len(people):
        dico[people[i]] = liste_amis(amis, people[i])
        i += 1
    return dico

def nb_amis_plus_pop (dico_reseau):
    """ Retourne le nombre d'amis des personnes ayant le plus d'amis."""
    personnes = list(dico_reseau)
    maxi = len(dico_reseau[personnes[0]])
    i = 1
    while i < len(personnes):
        if maxi < len(dico_reseau[personnes[i]]):
            maxi = len(dico_reseau[personnes[i]])
        i += 1
    return maxi


def les_plus_pop (dico_reseau):
    """ Retourne les personnes les plus populaires, c'est-à-dire ayant le plus d'amis."""
    max_amis = nb_amis_plus_pop(dico_reseau)
    most_pop = []
    personnes = list(dico_reseau)
    i = 1
    while i < len(personnes):
        if len(dico_reseau[personnes[i]]) == max_amis:
            most_pop.append(personnes[i])
        i += 1
    return most_pop

##############
# SAE S01.02 #
##############

def create_network(list_of_friends):
    dico={}                                 #initialisation du dictionnaire final
    tab=list_of_friends                     #simplification du nom de variable de la liste des amis
    for i in range(0,len(tab)//2):          #Boucle for qui fait que chaque i =i+2
        if tab[2*i] not in dico:            #si p1 n'est pas dans le dictionnaire 
            dico[tab[2*i]]=[tab[2*i+1]]     #alors on créer une clef pour elle et on lui rajoute comme valeur lié une liste contenant p2
        else:                               #sinon ça veut dire que p1 est déjà dedans donc on rajoute p2 dans la liste de valeur lié
            dico[tab[2*i]]+=[tab[2*i+1]]
        
        if tab[2*i+1] not in dico:          #si p2 n'est pas dans le dictionnaire 
            dico[tab[2*i+1]]=[tab[2*i]]     #alors on créer une clef pour elle et on lui rajoute comme valeur lié une liste contenant p1
        else:                               #sinon ça veut dire que p2 est déjà dedans donc on rajoute p1 dans la liste de valeur lié
            dico[tab[2*i+1]]+=[tab[2*i]]    #sinon ça veut dire qu'il est déjà 
    return dico



def get_people(network):
    return list(network.keys()) #en une ligne on creer une liste qui prend uniquement les valeurs clef du dictionnaire donc il n'y a naturellement pas de doublons dans la liste

def are_friends(network, person1, person2):
    if person1==person2:#Dans le cas ou les 2 personnes sont les mêmes on dit qu'elles sont amies(on a besoin de ça pour la foncion is_a_community)
        return True
    elif person1 not in network or person2 not in network: #On test si une des 2 personnes n'est pas dans le dictionnaire et si c'est le cas la réponsé est forcément False
        return False
    else:   
        return person2 in network[person1] #Sinon sachant que les amitiés sont réciproques , on retourne le résultat du test qui regarde si la personne 2 est dans la liste de valeurs lié a la personne 1


def all_his_friends(network, Originalperson, group):
    for person in group:    # On fait une boucle for qui parcours tout les élements du groupe
        if not are_friends(network, Originalperson, person): #si parmis les éléments du groupe , une personne n'est pas amis avec la personne de base,
            return False  #Alors la personne de base n'est pas amis avec tout les membres du groupe donc on renvoie False.
    return True     #Si on sort de la boucle alors la personne est amis avec toutes les autres.

def is_a_community(network, group):#Cette fonction teste si un groupe est une communauté ou non , une communauté est un groupe ou chaque personne a toute les autres en amis dans le groupe.
    for person in group: #On fait une boucle for qui pour chaque élement du groupe ,
        if not all_his_friends(network, person, group):#test si elle est amis ou non avec tout les autres
            return False#Si une des personne n'a pas toute les autres en amis alors ce n'est pas une communauté donc on renvoie False
    return True #Sinon cela veut dire que les personnes du groupe sont toutes amies entre elles.


def find_community(network, group):
    community = [] #on fait une communauté vide
    for elt in group :#pour chaque élement du groupe
        community.append(elt)#on ajoute l'élément dans la communauté
        if not is_a_community(network, community):#si le test de is_a_community est faux
            community.pop()#alors on enlève l'élément de la liste community sinon on le laisse et on continue
    return community #on renvoie la communauté
        

def order_by_decreasing_popularity(network, group):
    def nbamis(person):#on fait une autre fonction qui nous permet de compter le nombre d'amis d'une personne
        return len(network[person])#On retourn la longueur de la liste d'amis de la personne
    return sorted(group,key=nbamis, reverse=True)# cette commande permet de trié le group grace aux valeurs de la fonction nbamis dans l'ordre décroissants



def find_community_by_decreasing_popularity(network):
    liste_trié=order_by_decreasing_popularity(network, get_people(network))#on fait une liste trié des personnes du réseau
    community=find_community(network,liste_trié)#ouis avec cette liste on cherche la communauté avec find_community
    return community #on renvoie la communauté

def find_community_from_person(network, person):
    community=[person]#community est une liste qu'on initialise avec juste une valeur qui est la personne
    group=sorted(network[person])#on creer un groupe qui est la liste des amis trié de la personne en question
    community+=find_community(network,group)#puis on ajoute a la liste community , la communauté de find_community associé
    return community
    

def find_max_community(network):
    reseau=get_people(network)#on définit une variable réseau qui est la liste distincte des personne du réseau
    maxi=0#on définit un maximum a 0
    for elt in reseau: #pour chaque éléments de la liste reseau
        if len(find_community_from_person(network,elt))>maxi: #on regarde si la longueur de la liste d'amis associé a une personne(elt) est plus grande que maxi
            maxi=len(find_community_from_person(network, elt)) #si oui alors le maximum change sinon rien ne change et on passe a la personne suivante
            maxi_community=find_community_from_person(network, elt) #et on enregistre la communauté associé a la personne qui correspond au maximum
    return maxi_community #puis on renvoie la comunnauté
